% 1. Parametrii confirmați
k = 2420; 
tau = 37.8;
G1 = tf(k, [tau 1]);

% 2. Simularea răspunsului
[y_teoretic, t_teoretic] = step(G1 * 0.00003, 590);

% 3. Ajustarea OFFSET-ului (Pornim de la 0.001, nu de la 0)
offset = level1.Data(1); % adică acei 0.001 metri
t_final = [0; 10; t_teoretic + 10];
y_final = [offset; offset; y_teoretic + offset]; % adunăm offset-ul peste tot

% 4. Graficul de Validare
figure;
plot(level1.Time, level1.Data, 'b'); hold on;
plot(t_final, y_final, 'r');
grid on;
ylim([0 0.08]); % Forțăm axa să arate metri (0 la 8 cm)
legend('Real (Profesor)', 'Model Validat (G1)');


%%
% 1. Parametrii confirmați
k2 = 4220; 
tau2 = 75;
G2 = tf(k2, [tau2 1]);

% 2. Simularea răspunsului
[y_teoretic2, t_teoretic2] = step(G2 * 0.00003, 590);

% 3. Ajustarea OFFSET-ului (Pornim de la 0.001, nu de la 0)
offset2 = level2.Data(1); % adică acei 0.001 metri
t_final2 = [0; 10; t_teoretic2 + 10];
y_final2 = [offset2; offset2; y_teoretic2 + offset2]; % adunăm offset-ul peste tot

% 4. Graficul de Validare
figure;
plot(level2.Time, level2.Data, 'b'); hold on;
plot(t_final2, y_final2, 'r');
grid on;
ylim([0 0.08]); % Forțăm axa să arate metri (0 la 8 cm)
legend('Real (Profesor)', 'Model Validat (G2)');

%%
% 1. Parametrii confirmați
k3 = 4450; 
tau3 = 142.5;
G3 = tf(k3, [tau3 1]);

% 2. Simularea răspunsului
[y_teoretic3, t_teoretic3] = step(G3 * 0.00003, 590);

% 3. Ajustarea OFFSET-ului (Pornim de la 0.001, nu de la 0)
offset3 = level3.Data(1); % adică acei 0.001 metri
t_final3 = [0; 10; t_teoretic3 + 10];
y_final3 = [offset3; offset3; y_teoretic3 + offset3]; % adunăm offset-ul peste tot

% 4. Graficul de Validare
figure;
plot(level3.Time, level3.Data, 'b'); hold on;
plot(t_final3, y_final3, 'r');
grid on;
ylim([0 0.08]); % Forțăm axa să arate metri (0 la 8 cm)
legend('Real (Profesor)', 'Model Validat (G3)');

